from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Post, Comment, UserProfile

# 1. Home Page
def home(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'posts/home.html', {'posts': posts})

# 2. Post Details & Comments
def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    comments = post.comments.all().order_by('-created_at')
    
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return redirect('login')
        body = request.POST.get('body')
        if body:
            Comment.objects.create(post=post, author=request.user, body=body)
            return redirect('post_detail', pk=pk)
            
    return render(request, 'posts/post_detail.html', {'post': post, 'comments': comments})

# 3. Add New Post
@login_required
def add_post(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        body = request.POST.get('body')
        if title and body:
            Post.objects.create(title=title, body=body, author=request.user)
            return redirect('home')
    return render(request, 'posts/add_post.html')

# 4. Registration
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        gender = request.POST.get('gender')
        address = request.POST.get('address')
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user, gender=gender, address=address)
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'posts/register.html', {'form': form})

# 5. Login
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'posts/login.html', {'form': form})

# 6. Logout
def logout_view(request):
    logout(request)
    return redirect('home')
